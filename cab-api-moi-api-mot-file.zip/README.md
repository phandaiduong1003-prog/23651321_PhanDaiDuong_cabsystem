# CAB System API - Mỗi API một file YAML

Tổng số API: **26**

| STT | File | Method | Endpoint | Mô tả |
|---:|---|---|---|---|
| 1 | `01-post-registercustomer.yaml` | `POST` | `/auth/register` | Đăng ký tài khoản khách hàng |
| 2 | `02-post-login.yaml` | `POST` | `/auth/login` | Đăng nhập hệ thống |
| 3 | `03-get-getmyprofile.yaml` | `GET` | `/me/profile` | Xem hồ sơ hiện tại |
| 4 | `04-put-updatemyprofile.yaml` | `PUT` | `/me/profile` | Cập nhật hồ sơ cá nhân |
| 5 | `05-put-updatedriverprofile.yaml` | `PUT` | `/drivers/me/profile` | Cập nhật hồ sơ và dữ liệu phương tiện của tài xế |
| 6 | `06-put-updatedriverworkingstatus.yaml` | `PUT` | `/drivers/me/status` | Cập nhật trạng thái hoạt động của tài xế |
| 7 | `07-post-createbooking.yaml` | `POST` | `/bookings` | Tạo yêu cầu đặt xe |
| 8 | `08-post-accepttripoffer.yaml` | `POST` | `/trip-offers/{offerId}/accept` | Tài xế chấp nhận lời mời chuyến |
| 9 | `09-post-rejecttripoffer.yaml` | `POST` | `/trip-offers/{offerId}/reject` | Tài xế từ chối lời mời chuyến |
| 10 | `10-put-updatetripstatus.yaml` | `PUT` | `/trips/{tripId}/status` | Tài xế cập nhật trạng thái chuyến |
| 11 | `11-put-updatedriverlocation.yaml` | `PUT` | `/drivers/me/location` | Cập nhật vị trí tài xế |
| 12 | `12-get-gettriptracking.yaml` | `GET` | `/trips/{tripId}/tracking` | Theo dõi chuyến đi |
| 13 | `13-get-gettripfare.yaml` | `GET` | `/trips/{tripId}/fare` | Lấy số tiền của chuyến |
| 14 | `14-post-createtrippayment.yaml` | `POST` | `/trips/{tripId}/payments` | Ghi nhận hoặc thực hiện thanh toán chuyến |
| 15 | `15-get-getmytriphistory.yaml` | `GET` | `/customers/me/trips` | Xem lịch sử chuyến |
| 16 | `16-get-getmytriphistorydetail.yaml` | `GET` | `/customers/me/trips/{tripId}` | Xem chi tiết một chuyến trong lịch sử |
| 17 | `17-post-ratetrip.yaml` | `POST` | `/trips/{tripId}/ratings` | Đánh giá tài xế sau chuyến |
| 18 | `18-get-getcustomersforoperation.yaml` | `GET` | `/admin/customers` | Tra cứu và quản lý thông tin khách hàng |
| 19 | `19-get-getdriversforoperation.yaml` | `GET` | `/admin/drivers` | Tra cứu và quản lý dữ liệu tài xế |
| 20 | `20-put-updatedriverbyoperation.yaml` | `PUT` | `/admin/drivers/{driverId}` | Cập nhật dữ liệu tài xế |
| 21 | `21-get-getvehiclesforoperation.yaml` | `GET` | `/admin/vehicles` | Tra cứu thông tin phương tiện |
| 22 | `22-put-updatevehiclebyoperation.yaml` | `PUT` | `/admin/vehicles/{vehicleId}` | Cập nhật thông tin phương tiện |
| 23 | `23-get-getactivetripsforoperation.yaml` | `GET` | `/admin/trips` | Xem các chuyến đang hoạt động |
| 24 | `24-post-recordtripissuehandling.yaml` | `POST` | `/admin/trips/{tripId}/issues` | Ghi nhận xử lý trường hợp chuyến gặp vấn đề |
| 25 | `25-get-gettransactions.yaml` | `GET` | `/admin/transactions` | Tra cứu lịch sử giao dịch |
| 26 | `26-get-getoverviewreport.yaml` | `GET` | `/admin/reports/overview` | Xem báo cáo tổng quan |

## Cách dùng
Mỗi file là một tài liệu OpenAPI độc lập. Có thể import riêng từng file vào Swagger Editor.

## Ghi chú
- Mỗi file chỉ chứa đúng 1 operation/API.
- Các schema cần thiết cho API đó được giữ lại tự động.
- Không dùng YAML anchor/alias trong responses.
- `servers.url` vẫn là `/api/v1` vì README chưa quy định host/port backend thực tế.